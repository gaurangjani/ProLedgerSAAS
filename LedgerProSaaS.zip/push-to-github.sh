#!/bin/bash
# Run this once from any computer to push LedgerProSaaS to GitHub.
# Usage: bash push-to-github.sh
set -e
git init
git add -A
git commit -m "Initial LedgerPro SaaS — multi-tenant accounting platform"
git branch -M main
git remote add origin https://github.com/gaurangjani/LedgerProSaaS.git
git push -u origin main
echo "Done! Visit https://github.com/gaurangjani/LedgerProSaaS"
